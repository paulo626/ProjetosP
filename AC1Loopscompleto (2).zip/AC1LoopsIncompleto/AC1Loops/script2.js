var charmander ={
    Nome:'Charmander',
    Imagem:URL('/imagens/charmander.png'),
    Tipo:'',
    Poder:''}

var charizard ={
    Nome:'Charizard',
    Imagem:URL('/imagens/Charizard.png'),
    Tipo:'',
    Poder:''}

var ivysaur = {
    Nome:'Ivysaur',
    Imagem:URL('/imagens/Ivysaur.png'),
    Tipo:'',
    Poder:''}

var bulbasaur = {
    Nome:'Bulbasaur',
    Imagem:URL('/imagens/Bulbasaur.png'),
    Tipo:'',
    Poder:''}

var charmeleon = {
    Nome:'Charmeleon',
    Imagem:URL('/imagens/Charmeleon.png'),
    Tipo:'Fogo',
    Poder:'Charmeleon como suas outras formas evolutivas, pode respirar fogo'}