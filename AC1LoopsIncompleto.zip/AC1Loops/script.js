

function ValidarItem(item){
    if(item == null || item == undefined){
        return(false)
    }
    else if(isNaN(item)){
        return(true)
    }
    else{return(false)}}

function ValidarItemN(itemN){
    if(itemN ==null|| itemN==undefined){
        return(false)
    }
    else{
        return(true)
    }
}

function Nconta(){
    Validacao = false
   do{
        var V0 = false;
        do{ 
           var nome = prompt('digite se nome')
           var chamado0 = ValidarItem(nome)
           if(chamado0 == flase){alert('nome invalido')}
           else{
                if(nome.length<2){alert('nome invalido')}
                else{V0 = true}
            }
        }while(V0 = false);

        var V1 =false;
        do{
            var email = prompt('digite se email')
            var chamado1 = ValidarItem(email)
            if (chamado1 == flase){alert('email invalido')}
            else{V1 = true}
        }
        while(V1 === false)


        var V2 = false;
        do{
            var idade = parseInt(prompt('digite sua idade'))
            var chamado2 = ValidarItemN(idade)
            if(chamado2 == false){alert('idade invalida')}
            else{
                if(idade<0 || idade>100){alert('idade invalida')}
                else{V2 = true}
            }
        }while(V2 === false)


        var V3 =false;
        do{
            senha = prompt('digite uma senha(DEVE CONTER LETRAS E CARACTERES MINIMO 6 CARACTERES)')
            var chamado3 = ValidarItem(senha)
            if(senha){}
        }while(V3 === false)

    
}while(Validacao === false)}

function Validar(){
    let Login = document.getElementById('Login').value;
    let Senha = document.getElementById('Senha').value;
    const Alertar = document.getElementById('Alertar')

    if(Login == 'pokemon' && Senha == 'pokemon'){
        alert("login efetuado com sucesso")
        window.location.href = 'pagina2.html';
    }
    else{
        Alertar.style.color = 'red'
        Alertar.innerText = 'usuario ou senha invalido'
    }
}
/*var nomeDeUsuario = prompt('Nome completo')
        var Chamado1 = ValidarItem(nomeDeUsuario)
        if(Chamado1 === false){ alert("nome invalido")}
            else{
            if(nomeDeUsuario.length<2){
                alert('nome Invalido')
            }
                else{
                var email = prompt('email')
                var Chamado2 = ValidarItem(email)
                    if(Chamado2 = false){alert('email invalido')}
                        else{
                        var idade = parseInt(prompt('digite sua idade'))
                        var chamado3 = ValidarItemN(idade)
                            if (chamado3 == flase){alert('idade invalida')}
                            else{
                                if(idade<0 || idade>100){alert('idade invalida')}
                                else{
                                    var senha =prompt('digite sua senha(com letras e caracteres) minimo 6 caracteres')
                                    var chamado4 = ValidarItem(senha)
                                    if (chamado4 = false){alert('senha invalida')}
                                    else{
                                        var senhaConfirmada = prompt('confirme sua senha')
                                        var chamado5 = ValidarItem(senhaConfirmada)
                                        if(chamado5 = false){alert('senha de confirmação errada')}
                                        else{
                                            if(senha =! senhaConfirmada){
                                                alert('senhas diferentes')
                                            }
                                            else{
                                                
                                            }

                                        }
                                    }
                                }
                            }
                        } 
                    }
                }
     */